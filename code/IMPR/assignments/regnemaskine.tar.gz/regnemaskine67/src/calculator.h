#ifndef CALCULATOR_H
#define CALCULATOR_H
#include "data.h"

void do_next_op(Operation op, double operand, double* acc);
#endif
