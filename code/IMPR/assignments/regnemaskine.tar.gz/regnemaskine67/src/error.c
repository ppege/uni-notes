#include <stdio.h>
#include "error.h"

void report_error(Error error) {
    switch(error) {
        case DIVISION_BY_ZERO:
            printf("Error: division by zero\n");
            break;
        case NOT_REAL:
            printf("Error: result not real (negative square root)\n");
            break;
        case INVALID_SYNTAX:
            printf("Error: invalid syntax. Correct syntax is [operator] <operand>. Valid operations are:\n"
                   " + (addition)\n"
                   " - (subtraction)\n"
                   " * (multiplication)\n"
                   " / (division)\n"
                   " ^ (power)\n"
                   " # (square root)\n"
                   " %% (flip sign)\n"
                   " ! (reciprocal)\n"
                   " q (quit)\n");
            break;
    }
}
