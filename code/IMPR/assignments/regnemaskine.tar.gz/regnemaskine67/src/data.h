#ifndef DATA_H
#define DATA_H
#include <stdbool.h>

typedef enum Operation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE,
    POW,
    SQRT,
    FLIP,
    RECIPROCATE,
    QUIT,
    INVALID
} Operation;

typedef struct OperatorPair {
    char operator_symbol;
    Operation operation;
} OperatorPair;

bool get_value(char key, Operation* value);
Operation operation_from_char(char input);
bool take_input(char input[], int size);
bool parse_input(char input[], char* operator_symbol, double* operand);
#endif
