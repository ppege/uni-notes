#include <stdio.h>
#include <stdbool.h>
#include "calculator.h"
#include "error.h"

#define HELPER_TEXT "Valid operations are:\n"\
       " + (addition)\n"\
       " - (subtraction)\n"\
       " * (multiplication)\n"\
       " / (division)\n"\
       " ^ (power)\n"\
       " # (square root)\n"\
       " % (flip sign)\n"\
       " ! (reciprocal)\n"\
       " q (quit)\n"

double run_calculator();

int main() {
    printf("\n**********************\n"
             "|                    |\n"
             "|   regnemaskine67   |\n"
             "|                    |\n"
             "**********************\n\n"
             "%s\n\n", HELPER_TEXT);
    double result = run_calculator();
    printf("Final result: %lf\n", result);
    return 0;
}

double run_calculator() {
    double acc = 0;
    while (true) {
        printf("%lf\n", acc);
        char input[50];
        if (!take_input(input, 50)) {
            printf("Failed to read input.\n");
        }

        char operator_symbol;
        double operand;
        if (!parse_input(input, &operator_symbol, &operand)) {
            report_error(INVALID_SYNTAX);
            continue;
        }

        Operation op = operation_from_char(operator_symbol);
        if (op == INVALID) {
            printf("Invalid operation. %s", HELPER_TEXT);
            continue;
        }
        if (op == QUIT) {
            break;
        }
        do_next_op(op, operand, &acc);
    }
    return acc;
}
