#ifndef ERROR_H
#define ERROR_H

typedef enum Error {
    DIVISION_BY_ZERO,
    NOT_REAL,
    INVALID_SYNTAX
} Error;

void report_error(Error error);

#endif
