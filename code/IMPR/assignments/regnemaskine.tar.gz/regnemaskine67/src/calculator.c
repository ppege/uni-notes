#include <math.h>
#include "calculator.h"
#include "error.h"

void do_next_op(Operation op, double operand, double* acc) {
    switch(op) {
        case ADD:
            *acc += operand;
            break;
        case SUBTRACT:
            *acc -= operand;
            break;
        case MULTIPLY:
            *acc *= operand;
            break;
        case DIVIDE:
            if (operand == 0) {
                report_error(DIVISION_BY_ZERO);
                break;
            }
            *acc /= operand;
            break;
        case POW:
            *acc = pow(*acc, operand);
            break;
        case SQRT:
            if (*acc < 0) {
                report_error(NOT_REAL);
                break;
            }
            *acc = sqrt(*acc);
            break;
        case FLIP:
            *acc *= -1;
            break;
        case RECIPROCATE:
            if (*acc == 0) {
                report_error(DIVISION_BY_ZERO);
                break;
            }
            *acc = 1 / *acc;
            break;
        // these two cases should be unreachable!
        case QUIT:
            return;
        case INVALID:
            return;
    }
}
