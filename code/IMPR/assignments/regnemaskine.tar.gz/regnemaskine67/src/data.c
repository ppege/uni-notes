#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "data.h"

OperatorPair pairs[9] = {
    {'+', ADD},
    {'-', SUBTRACT},
    {'*', MULTIPLY},
    {'/', DIVIDE},
    {'^', POW},
    {'#', SQRT},
    {'%', FLIP},
    {'!', RECIPROCATE},
    {'q', QUIT},
};

bool get_value(char key, Operation* value) {
    // function to look up a operator symbol's corresponding operation
    for (int i = 0; i < 9; i++) {
        if (pairs[i].operator_symbol == key) {
            *value = pairs[i].operation;
            return true;
        };
    }
    return false; // returning a bool to handle invalid input
}

enum Operation operation_from_char(char input) {
    Operation operation;
    if (get_value(input, &operation)) {
        return operation;
    }
    return INVALID;
}

bool take_input(char input[], int size) {
    printf("> ");
    if (fgets(input, size, stdin)) {
        input[strcspn(input, "\n")] = '\0'; // remove trailing newline
        return true;
    }
    return false;
}

bool parse_input(char input[], char* operator_symbol, double* operand) {
    // i chose to call this parse_input instead of scan_data, as it feels more accurate.
    // the function is a bool for error handling purposes; in main, we printf the error information to the user and return if this returns false. the same is the case for the above take_input
    if (strlen(input) == 1) {
        *operator_symbol = input[0];
        *operand = 0; // let the operand be 0 as it will never be used
    } else {
        if (sscanf(input, "%c %lf", operator_symbol, operand) != 2) {
            // sscanf takes a string and does the same as scanf with the given input. if successful in getting both values, sscanf will return 2
            return false;
        }
    }
    return true;
}
